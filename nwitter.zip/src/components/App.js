import '../App.css';
import React,{useState} from 'react';
import Router from './Router'

function App() {
  return (
    <div>
      <Router />
    </div>
  );
}

export default App;
