import React from "react";

const EditProfile = () => <div>EditProfile</div>

export default EditProfile