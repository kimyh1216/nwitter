import React from "react";

const Auth = () => <div>Auth</div>

export default Auth